/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bhaskara;

/**
 *
 * @author Victor
 */
import java.util.Scanner;

public class Bhaskara {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        System.out.println("Calculadora de Bhaskara");
        
        System.out.print("Digite o valor de A: ");
        double a = leitor.nextDouble();
        
        System.out.print("Digite o valor de B: ");
        double b = leitor.nextDouble();
        
        System.out.print("Digite o valor de C: ");
        double c = leitor.nextDouble();

        double delta = Math.pow(b, 2) - (4 * a * c);

        if (delta < 0) {
            System.out.println("Delta negativo (" + delta + "). A equacao nao possui raizes reais.");
        } else {
            double x1 = (-b + Math.sqrt(delta)) / (2 * a);
            double x2 = (-b - Math.sqrt(delta)) / (2 * a);

            System.out.printf("Delta: %.2f%n", delta);
            System.out.printf("x1: %.2f%n", x1);
            System.out.printf("x2: %.2f%n", x2);
        }
        
        leitor.close();
    }
}

