/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.atividadeds1;
import javax.swing.JOptionPane;

/**
 *
 * @author Victor
 */

public class AtividadeDS1 {

    public static void main(String[] args) {
        int a;
        a = Integer.parseInt(JOptionPane.showInputDialog("Digite um número"));
        dobro(a);   
    }   
    
    static void dobro(int n) {
        int d = n * 2 ;
        
        JOptionPane.showMessageDialog(null, "Dobro de " +n+ " é " + d );
        
    }
}
