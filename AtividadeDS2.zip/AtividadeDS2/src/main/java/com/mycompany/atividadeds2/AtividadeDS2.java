/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.atividadeds2;

import javax.swing.JOptionPane;

/**
 *
 * @author Victor
 */
public class AtividadeDS2 {

    public static void main(String[] args) {

        int t;
        String p;
        digite();
        p = JOptionPane.showInputDialog("Digite uma palavra qualquer");
        t = tamanho(p);
        JOptionPane.showMessageDialog(null, p + " possui " + t + " caracteres");
    }

    static void digite() {
        JOptionPane.showMessageDialog(null, "Digite uma palavra");
    }
    
    static int tamanho (String x) {
        return  x.length();
    }
    
}
